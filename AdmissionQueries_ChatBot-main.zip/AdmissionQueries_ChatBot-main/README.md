# AdmissionQueries_ChatBot
ChatBot for the new students to get help this is a flask app and used python and natural language processing.
